import React from 'react'

const Plans = () => {
  return (
    <div>
      
    </div>
  )
}

export default Plans
