import React from 'react'

const Relationship = () => {
  return (
    <div>
      
    </div>
  )
}

export default Relationship
