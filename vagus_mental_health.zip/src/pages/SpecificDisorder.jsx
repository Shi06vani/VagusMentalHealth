import React from 'react'

const SpecificDisorder = () => {
  return (
    <div>
      
    </div>
  )
}

export default SpecificDisorder
