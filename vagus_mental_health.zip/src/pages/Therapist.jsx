import React from 'react'

const Therapist = () => {
  return (
    <div>
      
    </div>
  )
}

export default Therapist
