import React from 'react'

const LifeAndWork = () => {
  return (
    <div>
      
    </div>
  )
}

export default LifeAndWork
