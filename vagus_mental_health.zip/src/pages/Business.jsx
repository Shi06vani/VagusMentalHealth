import React from 'react'

const Business = () => {
  return (
    <div>
      
    </div>
  )
}

export default Business
