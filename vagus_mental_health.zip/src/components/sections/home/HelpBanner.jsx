import React from 'react'

const HelpBanner = () => {
  return (
    <div>
      
    </div>
  )
}

export default HelpBanner
