import React from 'react'

const RecoveryJourney = () => {
  return (
    <div>
      
    </div>
  )
}

export default RecoveryJourney
