import React from 'react'

const HowWeWork = () => {
  return (
    <div>
      
    </div>
  )
}

export default HowWeWork
