import React from 'react'

const FAQ = () => {
  return (
    <div>
      
    </div>
  )
}

export default FAQ
