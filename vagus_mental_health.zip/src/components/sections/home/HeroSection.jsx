import React from 'react'

const HeroSection = () => {
  return (
    <div>
      HeroSection ddfgdfgdgd
    </div>
  )
}

export default HeroSection
